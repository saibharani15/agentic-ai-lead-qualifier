from pydantic import BaseModel


class LeadInput(BaseModel):
    name: str
    email: str
    company: str
    message: str


class LeadQualificationResult(BaseModel):
    company_summary: str
    score: int
    fit_reasoning: str
    follow_up_email: str
