from fastapi import FastAPI
from schemas import LeadInput, LeadQualificationResult
from lead_workflow import qualify_lead

app = FastAPI(title="Agentic AI Lead Qualifier")


@app.get("/")
def healthcheck():
    return {"status": "ok"}


@app.post("/qualify", response_model=LeadQualificationResult)
def qualify(lead: LeadInput):
    result = qualify_lead(
        name=lead.name,
        email=lead.email,
        company=lead.company,
        message=lead.message,
    )
    return result
