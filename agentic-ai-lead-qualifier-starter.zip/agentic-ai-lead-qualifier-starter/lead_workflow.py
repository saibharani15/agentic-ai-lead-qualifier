from typing import Dict


def research_company(company: str) -> Dict[str, str]:
    # Replace with Clearbit, Apollo, CRM, or web research integrations
    return {
        "industry": "Retail Technology",
        "size": "50-200 employees",
        "signal": f"{company} appears to be investing in automation and workflow efficiency."
    }


def score_fit(lead_message: str, company_data: Dict[str, str]) -> Dict[str, str]:
    score = 84 if "automating" in lead_message.lower() or "automation" in lead_message.lower() else 71
    reasoning = (
        "Strong fit based on automation intent, likely operational pain points, "
        "and company profile alignment with our ideal customer profile."
    )
    return {"score": score, "reasoning": reasoning}


def draft_follow_up(name: str, company: str, message: str, company_data: Dict[str, str]) -> str:
    return (
        f"Hi {name},\n\n"
        f"Thanks for reaching out. I noticed that {company} operates in {company_data['industry']} "
        f"and may be exploring workflow efficiency initiatives. Based on your note about \"{message}\", "
        f"I believe there may be a strong fit for an AI-driven automation solution.\n\n"
        f"I would love to share how similar teams streamline repetitive workflows using agentic AI systems. "
        f"Would you be open to a quick conversation next week?\n\n"
        f"Best,\nSai Bharani"
    )


def qualify_lead(name: str, email: str, company: str, message: str) -> Dict[str, str]:
    company_data = research_company(company)
    score_data = score_fit(message, company_data)
    follow_up = draft_follow_up(name, company, message, company_data)

    return {
        "company_summary": (
            f"{company} is in {company_data['industry']}, with {company_data['size']}. "
            f"Signal detected: {company_data['signal']}"
        ),
        "score": score_data["score"],
        "fit_reasoning": score_data["reasoning"],
        "follow_up_email": follow_up,
    }
