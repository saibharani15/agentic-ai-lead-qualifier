# Agentic AI Lead Qualifier

A starter project for an AI agent that qualifies inbound leads by researching the company, scoring fit, and drafting a personalized follow-up.

## What it does
- Accepts a lead payload
- Enriches the company with mock research data
- Scores fit against ICP criteria
- Drafts a personalized email follow-up
- Returns structured JSON output

## Tech Stack
- Python 3.11
- FastAPI
- OpenAI-compatible client pattern
- Modular agent-style workflow

## Project Structure
- `app.py` - FastAPI entry point
- `lead_workflow.py` - multi-step orchestration
- `schemas.py` - request/response models
- `requirements.txt` - dependencies

## Run locally
```bash
pip install -r requirements.txt
uvicorn app:app --reload
```

## API
POST `/qualify`

Example body:
```json
{
  "name": "Jane Doe",
  "email": "jane@acme.com",
  "company": "Acme Health",
  "message": "Interested in automating our support workflows."
}
```

## Notes
This starter is designed to demonstrate architecture, orchestration, and production-minded structure for an Agentic AI Developer application.
